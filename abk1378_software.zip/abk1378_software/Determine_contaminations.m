% load "Determine_contamination_sample" into workspace

% "STD_baseline_Cb" is the average of all mean standard deviations of deltaF/F
% baseline values from cerebellar two-photon microscopy noradrenergic
% terminal experiments

% "locomotion_start" contains the start frames of all 8 locomotion or
% locomotion + visual stimulation trials

% "data_mean_trace_Fig2D" is the representative mean Ca2+ fluorescence trace presented in Fig.2D

% "contamination" contains a 1 for trials which were contaminated by voluntary locomotion, and otherwise a 0

contamination = NaN(1,8);
data = data_mean_trace_Fig2D;
for i = 1:8
    test = data(1,(locomotion_start(i,1)-110):(locomotion_start(i,1)-1)) > (3 * STD_baseline_Cb);
    test = Fun_contiguous_ones(test);
    test = max(test(:,1));
    if test>2
        contamination(1,i) = 1;
    else
        contamination(1,i) = 0;
    end
end
