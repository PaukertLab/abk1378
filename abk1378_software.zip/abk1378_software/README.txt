# abk1378

This repository contains MATLAB functions that were developed to facilitate analysis and presentation of data
contained in

"Noradrenergic terminal short-term potentiation enables modality-selective integration of sensory input and vigilance state"

by

Shawn R. Gray#, Liang Ye#, Jing Yong Ye, Martin Paukert*
(#, equal contribution; *, paukertm@uthscsa.edu)

Determine_contaminations.m serves to objectively determine whether an enforced locomotion or enforced locomotion + visual stimulation trial has been contaminated by preceding voluntary locomotion of the mouse, which would result in elimination of such a trial from
analysis. Instructions are provided as comments within the m-file.
Dependencies: Fun_contiguous_ones.m

Sample_contamination_determination_Fig2D.mat has been provided to test run this routine.


Fun_chained_dot_plot_SA_Feb2019.m serves to plot dependent or independent multi-factor data sets. Instructions are
provided as comments within the m-file.
Dependencies: N/A

Sample_chained_dot_plot_Fig5E_left.mat has been provided to test run this routine.


Statistics_RM_3_groups.m serves to conduct a 3 groups repeated measures analysis of variance (ANOVA). Instructions are
provided as comments within the m-file.
Dependencies: N/A

Sample_statistics_Fig5E_data.mat has been provided to test run this routine.



System requirements: any system that allows to run MATLAB R2016a including the Statistics and Machine Learning Toolbox
Installation guide: included as comments in scripts, install time: 10 min
Demo: included as comments in scripts, run time: <1 s
Instructions for use: included as comments in scripts - sample data are provided for testing.


Address questions to Martin Paukert (paukertm@uthscsa.edu)

September 2, 2021

