% Repeated Measures ANOVA for three groups followed by Tukey-Kramer
% correction for multiple comparisons (example for data of Fig. 5E)

% load variable "Data" from "Sample_statistics_Fig5E_data.mat" into workspace

% organization of Data:

% 1. column: locomotion (aCSF)
% 2. column: co-stimulation (aCSF)
% 3. column: locomotion (D-AP5)
% 4. column: co-stimulation (D-AP5)
% 5. column: locomotion (L-NMMA)
% 6. column: co-stimulation (L-NMMA)

T = table();
T.drugs = {'aCSF';'aCSF';'aCSF';'aCSF';'aCSF';'aCSF';'aCSF';'D-AP5';'D-AP5';'D-AP5';'D-AP5';'D-AP5';'D-AP5';'D-AP5';'D-AP5';'L-NMMA';'L-NMMA';'L-NMMA';'L-NMMA';'L-NMMA';'L-NMMA';'L-NMMA';'L-NMMA'};
T.locomotion = cat(1,Data(1:7,1),Data(1:8,3),Data(1:8,5));
T.co_stimulation = cat(1,Data(1:7,2),Data(1:8,4),Data(1:8,6));
within = table();
within.conditions = categorical({'locomotion';'co_stimulation'});
rm = fitrm(T,'locomotion,co_stimulation ~ drugs','WithinDesign',within);
tbl = multcompare(rm,'conditions','By','drugs','ComparisonType','tukey-kramer');
